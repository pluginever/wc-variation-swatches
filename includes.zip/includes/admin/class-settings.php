<?php

namespace Pluginever\WcVariationSwatches\Admin;
class Settings {

}
