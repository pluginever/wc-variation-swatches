<?php

namespace Pluginever\WcVariationSwatches;

class ShortCode {

	/**
	 * ShortCode constructor.
	 */
	public function __construct() {

	}

}
