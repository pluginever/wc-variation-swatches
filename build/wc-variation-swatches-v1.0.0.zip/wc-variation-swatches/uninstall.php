<?php
/**
 * WcVariationSwatches Uninstall
 *
 * Uninstalling WcVariationSwatches deletes user roles, pages, tables, and options.
 *
 * @package WcVariationSwatches\Uninstaller
 * @version 1.0.0
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
