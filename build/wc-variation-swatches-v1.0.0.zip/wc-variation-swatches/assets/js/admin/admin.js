jQuery(document).ready(function($){
	
    $('.taxonomy-color-field').wpColorPicker();
});